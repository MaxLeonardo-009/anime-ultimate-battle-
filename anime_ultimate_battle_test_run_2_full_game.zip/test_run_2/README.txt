ANIME ULTIMATE BATTLE — TEST RUN 2.0

This package is the combined development test package for Stages 1–10.

Open:
  test_run_2/index.html

It provides a single test entry point with:
- Story Mode prototype
- Ultimate Battle 5-team concept entry
- Offline Multiplayer entry
- Online Battle test entry
- Arena Select with all 10 official arena references
- Nexus Battle Arena 3D combat test
- Max vs Nexus Rival
- Mobile analog movement
- Attack / Special / Dodge / Block / Ultimate
- Health and Ultimate meters
- Basic progression display

IMPORTANT:
This is a playable prototype, not a finished Android APK and not a production online game.
The 10 arenas are currently selection/reference entries; the Nexus arena is the playable 3D test arena.
The online mode is a test entry, not a live global server.
Third-party anime characters are not included until licensing is obtained.

The package also contains a STAGES_1_TO_10 folder with the development plan and Stage 10 progression foundation.
