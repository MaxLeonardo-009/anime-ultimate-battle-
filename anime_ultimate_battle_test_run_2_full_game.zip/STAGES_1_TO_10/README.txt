Anime Ultimate Battle — Combined Stage Map

1. Nexus Battle Arena / core visual reference
2. Full 3D foundation
3. Combat prototype
4. Story mode
5. Character/forms design
6. Ultimate Battle 5v5 concept
7. Offline multiplayer
8. Online networking foundation
9. Matchmaking / rooms / ranked
10. Accounts / progression / leaderboard foundation

The test_run_2 folder is the single playable entry point for this development build.
Future stages can be added to this same package rather than creating separate games.
